/*
	MoPicchu stack engine (using strings)
	Copyright (c) 2008 Samuel Saint-Pettersen
	Released under the MIT License
	Implementation code for MoPicchu stack engine
*/

#include "MoPicchu.h"
#include "nsStringAPI.h"
#include <cstring>

NS_IMPL_ISUPPORTS1(MoPicchu, IMoPicchu)

// 
// Constructor
//
MoPicchu::MoPicchu() {}

// 
// Destructor
//
MoPicchu::~MoPicchu() {}

//
// Declare Stack class
//
class Stack {
	int i; // Index
	char val[100][50]; // Array holding values
	int size; // Number of values the structure can store

public:
	Stack() { i = 0; } // Stack constructor; set index to 0
	void defSize(int s) { size = s; } // Define size for stack
	int retIndex() { return i; } // Return the current index of the stack
	int retSize() { return size; } // Return size of the stack
	void drop(const char v[]) { // Drop passed value to selected index on the stack
		strcpy(&val[i][0], v); 
	} 
	char *pull() { return val[i]; } // Pull value from the current index on the stack
	void pop() { // Pop (clear) value from the current index on the stack
		const char v[] = "";
		strcpy(&val[i][0], v);
	} 
	void shiftUp() { i++; } // Shift to next index for next value drop
	void shiftDwn() { i--; } // Shift to previous index for next value pull
	void setTop() { int top = size - 1; i = top; } // Set index to top of the stack
};

// 
// Create the Stack object
//
Stack IStack;

//
// Define size of the Stack (or return sizes with argument -1/-2)
//
NS_IMETHODIMP MoPicchu::Define(PRInt32 psize, PRInt32 *_retval) {

	int max = 100; // Define maximum allowable stack size

	// Define the stack size if psize > 0 and <= max size
	if(psize > 0 && psize <= max) {
		IStack.defSize(psize);
	}

	// If invalid size is provided, force maximum allowable size
	else if(psize == 0 || psize > max) IStack.defSize(max);

	// If argument is -1, return size of the stack
	else if(psize == -1) *_retval = IStack.retSize();

	// If argument is -2, return maximum allowable stack size
	else if(psize == -2) *_retval = max;

    return NS_OK;
}

//
// Drop value onto the Stack (extra drop to indicate end of drops)
//
NS_IMETHODIMP MoPicchu::Drop(const char *pval) {

	// While current stack index <= stack size, drop value
	if(IStack.retIndex() <= (IStack.retSize() - 1)) { 
		IStack.drop(pval);
		IStack.shiftUp();
	}
	// On extra drop, set index to top for pulling
	else if(IStack.retIndex() > (IStack.retSize() - 1)) IStack.setTop(); 

	return NS_OK;
}

//
// Pull value from the Stack
//
NS_IMETHODIMP MoPicchu::Pull(nsACString & _retval) {

	// While current stack index > -1 and <= stack size, pull value and decrement index
	if(IStack.retIndex() > -1 && IStack.retIndex() <= (IStack.retSize() - 1)) {
		_retval.Assign(IStack.pull());
		IStack.pop();
		IStack.shiftDwn();
	}
	else _retval.Assign("End of Stack"); // Otherwise, return "End of Stack"

    return NS_OK;
}

// 
// Reset the Stack
//
NS_IMETHODIMP MoPicchu::Reset() {

	// While incrementer < stack size, pop current index value and decrement index
	for(int i = 0; i < (IStack.retSize() - 1); i++) {
		IStack.pop();
		IStack.shiftDwn();
	}

    return NS_OK;
}
