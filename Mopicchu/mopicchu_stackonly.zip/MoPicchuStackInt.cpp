/*
	MoPicchu stack engine (using integers)
	Copyright (c) 2008 Samuel Saint-Pettersen
	Released under the MIT License
	Implementation code for MoPicchu stack engine
*/

#include "MoPicchu.h"
#include "nsStringAPI.h"

NS_IMPL_ISUPPORTS1(MoPicchu, IMoPicchu)

// 
// Constructor
//
MoPicchu::MoPicchu() {}

// 
// Destructor
//
MoPicchu::~MoPicchu() {}

//
// Declare Stack class
//
class Stack { // ! use +ints for now
	int i; // Index
	int val[100]; // Array holding values 
	int size; // Number of values the stack can store

public:
	Stack() { i = 0; val[i] = 0; } // Stack constructor; set index to 0
	void defsize(int s) { size = s; } // Define size for stack with passed value
	int retindex() { return i; } // Return the current index of the stack
	int retsize() { return size; } // Return size of the stack
	bool checknull() { // Check whether current index value is 0; return true or false
		if(val[i] == 0) return true; else return false; 
	}
	void drop(int v) { val[i] = v; } // Drop passed value to selected index on the stack
	int pull() { return val[i]; } // Pull value from the current index on the stack
	void pop() { val[i] = 0; } // Pop (clear) value from the current index on the stack
	void shiftUp() { i++; } // Shift to next index for next value drop
	void shiftDwn() { i--; } // Shift to previous index for next value pull
	void settop() { int top = size - 1; i = top; } // Set index to top of the stack (void)
};

// 
// Create the Stack object
//
Stack IStack;

//
// Define size of the Stack (or return sizes with argument -1/-2)
//
NS_IMETHODIMP MoPicchu::Define(PRInt32 psize, PRInt32 *_retval) {

	int max = 100; // Define maximum allowable stack size

	// Define the stack size if psize > 0 and <= max size
	// Return -3; indicating the stack size has been set
	if(psize > 0 && psize <= max) {
		IStack.defsize(psize);
		*_retval = -3;
	}

	// If invalid size provided, return -4; which indicates invalid value
	else if(psize == 0 || psize > max) *_retval = -4;

	// If argument is -1, return size of stack
	else if(psize == -1) *_retval = IStack.retsize();

	// If argument is -2, return maximum allowable stack size
	else if(psize == -2) *_retval = max;

    return NS_OK;
}

//
// Drop value onto the Stack (call after last drop w/ -1 to indicate end of drops)
//
NS_IMETHODIMP MoPicchu::Drop(PRInt32 pval) { 

	// While current stack index <= stack size...
	if(IStack.retindex() <= (IStack.retsize() - 1)) {
		// ... and index value is 0; drop value
		if(IStack.checknull()) {
			IStack.drop(pval);
			IStack.shiftUp();
		} 
		// Otherwise, just shift up an index
		else IStack.shiftUp();
	}
	else if(pval == -1) IStack.settop(); // on -1 drop beyond stack range; set index to top for pulling

	return NS_OK;
}

//
// Pull value from the Stack
//
NS_IMETHODIMP MoPicchu::Pull(PRInt32 *_retval) {

	// While current stack index > -1 and <= stack size; pull value and decrement index
	if(IStack.retindex() > -1 && IStack.retindex() <= (IStack.retsize() - 1)) {
		*_retval = IStack.pull();
		IStack.pop();
		IStack.shiftDwn();
	}
	else *_retval = -5; // Otherwise, return -5; indicates end of the stack

    return NS_OK;
}

// 
// Reset the Stack
//
NS_IMETHODIMP MoPicchu::Reset() {

	// While incrementer < stack size; pop current index value and shift down indices
	for(int i = 0; i < (IStack.retsize() - 1); i++) {
		IStack.pop();
		IStack.shiftDwn();
	}

    return NS_OK;
}
